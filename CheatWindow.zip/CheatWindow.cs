﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEditor;// << : 




public class CheatWindow : EditorWindow {

    string[] cheatList = new string[] {
            "치트", /// :string 
            "골드 생성" , /// : int 
            "포인트 생성",   /// : int 
    };

    static int selectedIndex = 0;

    int getInt = 0;
    string getString = "";

    [MenuItem("SGAMenu/SubMenu/치트명령창")]
    static public void OpenCheatWindow()
    {
        Debug.Log("치트 명령창"); 
    }

    [MenuItem("SGAMenu/SubMenu/치트명령창1",false , 0)]
    static public void OpenCheatWindow1()
    {
        CheatWindow getWindow = EditorWindow.GetWindow<CheatWindow>(
                                                false,
                                                "Cheat Window",
                                                true); 
    }

    [MenuItem("SGAMenu/SubMenu/치트명령창2", true, 0)]
    static public void OpenCheatWindow2()
    {
        CheatWindow getWindow = EditorWindow.GetWindow<CheatWindow>(
                                                false,
                                                "Cheat Window",
                                                true);
    }
    
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnGUI()
    {
        GUILayout.Space(10.0f);

        int getIndex = EditorGUILayout.Popup(selectedIndex,
                                            cheatList,
                                            GUILayout.MaxWidth(200.0f)
                                            );

        if (selectedIndex != getIndex)
        {
            selectedIndex = getIndex; 
        }

        string cheatText = "";


        if (selectedIndex == 0)   // : cheat key
        {
            GUILayout.BeginHorizontal(GUILayout.MaxWidth(300.0f));

            GUILayout.Label("치트키 입력", GUILayout.Width(70.0F));

            getString = EditorGUILayout.TextField(getString,
                                            GUILayout.Width(100.0f));

            GUILayout.EndHorizontal();

            cheatText = string.Format("치트키 : {0}", getString);

        } // << : 
        else if (selectedIndex == 1)
        {
            GUILayout.BeginHorizontal(GUILayout.MaxWidth(300.0f));

            GUILayout.Label("골드", GUILayout.Width(70.0F));

            getString = EditorGUILayout.TextField(getString,
                                            GUILayout.Width(100.0f));

            GUILayout.EndHorizontal();

            int.TryParse(getString, out getInt); 

            cheatText = string.Format("골드 : {0}", getInt);
        }
        else if(selectedIndex == 2)
        {
            GUILayout.BeginHorizontal(GUILayout.MaxWidth(300.0f));

            GUILayout.Label("포인트", GUILayout.Width(70.0F));

            getString = EditorGUILayout.TextField(getString,
                                            GUILayout.Width(100.0f));

            GUILayout.EndHorizontal();

            int.TryParse(getString, out getInt);

            cheatText = string.Format("포인트 : {0}", getInt);
        }

        // >> :button 
        GUILayout.Space(20.0f);
        GUILayout.BeginHorizontal(GUILayout.MaxWidth(800.0f));

        GUILayout.BeginVertical(GUILayout.MaxWidth(300.0f)); 

            GUILayout.BeginHorizontal(GUILayout.MaxWidth(300.0f));
                if (GUILayout.Button("\n적용\n", GUILayout.Width(100.0f)))
                {
                    if (EditorApplication.isPlaying &&
                        EditorApplication.currentScene != "Title")
                    {
                        getInt = 0;
                        getString = "";
                        Debug.Log(cheatText); 
                    }
                }
            GUILayout.EndHorizontal();


            GUILayout.BeginHorizontal(GUILayout.MaxWidth(300.0f));
            if (GUILayout.Button("\n백그라운드\n실행\n",
                            GUILayout.Width(100.0f)))
            {
                Application.runInBackground = true; 
            }
            if (GUILayout.Button("\n백그라운드\n실행 안함\n",
                GUILayout.Width(100.0f)))
            {
                Application.runInBackground = false;
            }
            GUILayout.EndHorizontal();
        
        GUILayout.EndVertical(); 
        GUILayout.EndHorizontal();
    }
}
